/**
 * Class Golfer - contains a golfer's game information
 * 
 * A golfer object contains the golfer's first and last name, their score, and the number of holes completed.
 * 
 * @author Alec Porter
 */
public class Golfer {
    
    private String firstName;
    private String lastName;
    private int score;
    private int holesCompleted;

    // Golfer constructor
    public Golfer(String firstName, String lastName, int score, int holesCompleted){
        this.firstName = firstName;
        this.lastName = lastName;
        this.score = score;
        this. holesCompleted = holesCompleted;
    }

    /**
     * This method overrides the string method and prints the current game status of the golfer.
     * 
     * @return string of the form: lastName, firstName: score with holesCompleted holes completed
     */
    @Override
    public String toString(){
        return lastName + ", " + firstName + ": " + score + " with " + holesCompleted + " holes completed";
    }
    

}
