import java.util.ArrayList;

public class Driver {
    public static void main(String[] args) throws Exception {
        
        // create arraylist to store golfer objects
        ArrayList<Golfer> golfers = new ArrayList<>();

        // add golfers
        golfers.add(new Golfer("Smith", "Jay", -13, 17));
        golfers.add(new Golfer("Smith", "DeShaun", -11, 16));
        golfers.add(new Golfer("Doe", "Jane", 0, 0));

        // print golfer arraylist
        System.out.println(golfers);
        System.out.println();

        // print golfer status on indiviuals lines
        for (Golfer person : golfers){
            System.out.println(person);
        }



    }
}
